"""A collection of functions for doing my project."""

import string
import random

from datetime import datetime


def is_question(input_string):
    """External code from A3. Check if the input is a question.
    
    Parameters
    ----------
    input_string : str
        Input string.
    
    Returns
    -------
    output : bool
        The result of check. 
    """
    
    question_words = ['?', 'who', 'what', 'when', 'where', "how"]
    
    for item in input_string:
    
        if item in question_words:
            output = True
            
        else:
            output = False
        
    return output


def remove_punctuation(input_string):
    """External code from A3. Remove punctuations from input.
    
    Parameters
    ----------
    input_string : str
        Input string.
    
    Returns
    -------
    out_string : str
        String after removed all punctuations.
    """
    
    out_string = ''
    
    for char in input_string:
        
        if char not in string.punctuation:
            out_string += char
            
    return out_string


def prepare_text(input_string):
    """External code from A3. Split the input string to a word list.
    
    Parameters
    ----------
    input_string : str
        Input string.
    
    Returns
    -------
    out_list : list
        List that contains all separtate strings from input.
    """
    
    temp_string = input_string.lower()
    temp_string = remove_punctuation(temp_string)
    out_list = temp_string.split()
    
    return out_list


def selector(input_list, check_list, return_list):
    """External code from A3. If the input contains the same word with the pre-designed word list,
        select a random response from the pre-designed response list.
    
    Parameters
    ----------
    input_list : list
        List that contains all separate strings from input.
        
    check_list : list
        Pre-designed word list to check the keyword.
    
    return_list : list
        Pre_designed response list.
    
    Returns
    -------
    output : str
        String that is randomly chosed from response list.
    """
    
    output = None
    
    for word in input_list:
        
        if word in check_list:
            output = random.choice(return_list)
            break

    return output


def end_chat(input_list):
    """External code from A3. End the chat if the input contains words "quit" or "bye".
    
    Parameters
    ----------
    input_list : list
        List that contains all separate strings from input.
    
    Returns
    -------
    output : bool
        The result of check whether 'quit' or 'bye' appeared in input.
    """
    
    end_words = ['quit', 'bye']
    
    for item in end_words:
        
        if item in input_list:
            output = True
            
        else:
            output = False
        
    return output


def is_in_list(list_one, list_two):
    """External code from A3. Check if any element of list_one is in list_two.
    
    Parameters
    ----------
    list_one : list
        Input list to check.
    
    list_two : list
        List to check from
    
    Returns
    -------
    Boolean : bool
        The result of check.
    """
    
    for element in list_one:
        
        if element in list_two:
            return True
        
    return False


def find_in_list(list_one, list_two):
    """External code from A3.Check if any element of list_one is in list_two, and return this same element if so.
    
    Parameters
    ----------
    list_one : list
        List to check.
    
    list_two : list
        List to check from.
        
    Returns
    -------
    element : bool
        The same element that in both lists.
    """
    
    for element in list_one:
        
        if element in list_two:
            return element
        
    return None


def is_in_both_lists(list_one, list_two, list_three):
    
    """Check if elements of list_one is in both list_two and list_three.
    
    Parameters
    ----------
    list_one : list
        List to check.
    
    list_two : list
        List to check from.
    
    list_three : list
        List to check from.
        
    Returns
    -------
    output : bool
        The result of check.
    """
    
    if is_in_list(list_one, list_two) and is_in_list(list_one, list_three):
        output = True
    
    else:
        output = False
    
    return output


def is_weekday(input_list):
    """Check if the plan-day (stated in the input) is a weekday or not.
    
    Parameters
    ----------
    input_list : list
        List that contains all separate strings from input.
        
    Returns
    -------
    Boolean : bool
        The result of check.
    """
    
    now = datetime.today()
    
    for item in input_list:
        
        if item in ['monday','tuesday','wednesday','thursday','friday']:
            return True
            
        elif item in ['saturday','sunday']:
            return False
        
        elif item == 'today':
            
            day_count = now.isoweekday()
            
            if day_count <=5:
                return True
            
            else:
                return False          
            
        elif item == 'tomorrow':
            
            day_count = now.isoweekday() + 1
            
            if day_count <= 5:
                return True
            
            else:
                return False
            
            
def hours_info(input_list, place_in, day_in, hours_dict):
    """Return a hours information (somewhere's hours in a certain day) with different input keywords. 
    
    Parameters
    ----------
    input_list : list
        List that contains all separate strings from input.
    
    place_in : list
        A pre-designed place list.
    
    day_in : list
        A pre-designed date list.
        
    hours_dict : dict
        A pre_designed dictionary that states different hours depends on different day of a week.
    
    Returns
    -------
    answer : str
        A pre_designed sentence with several variable words.
        
    """
    
    place = find_in_list(input_list, place_in)
    day = find_in_list(input_list, day_in)
    hours = hours_dict[day]
    
    ansnwer = place.capitalize() + ' is open on ' + day.capitalize() + ' at ' + hours
    
    return ansnwer