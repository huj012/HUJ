"""Test for my functions."""

from functions import is_in_both_lists, is_weekday, hours_info

##
##

def test_is_in_both_lists():
    
    assert callable(is_in_both_lists)
    assert isinstance(is_in_both_lists(['a', 'b'], ['a', 'c'], ['b', 'c']), bool)
    assert is_in_both_lists(['Geisel', 'Tuesday'], ['Geisel'], ['Tuesday']) == True
    
    
def test_is_weekday():
    
    assert callable(is_weekday)
    assert isinstance(is_weekday(['today']), bool)
    assert (is_weekday(['tuesday']) == True)
    assert (is_weekday(['saturday']) == False)
    
    
def test_hours_info():
    
    assert callable(hours_info)
    assert isinstance(hours_info(['a', 'b'], ['a'], ['b'], {'b': 'd'}), str)
    assert hours_info(['tuesday', 'geisel'], ['geisel'], \
                       ['tuesday'], {'tuesday': '7'} ) == 'Geisel is open on Tuesday at 7'